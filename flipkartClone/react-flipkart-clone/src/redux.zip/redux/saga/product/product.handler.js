import { call, put } from "redux-saga/effects";
import { getCategoriesService } from "./product.service";
import { saveCategories } from "../../product.slice";

export function* getCategoriesHandler() {
  try {
    let data = yield call(getCategoriesService);
    yield put(saveCategories(data));
  } catch (error) {
    alert("server error");
  }
}
